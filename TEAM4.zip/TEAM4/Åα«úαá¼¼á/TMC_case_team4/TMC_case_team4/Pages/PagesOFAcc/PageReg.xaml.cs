﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.PagesOFAcc
{
    /// <summary>
    /// Логика взаимодействия для PageReg.xaml
    /// </summary>
    public partial class PageReg : Page
    {
        public PageReg()
        {
            InitializeComponent();
        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            if(tb_surname.Text != "")
            {
                if (tb_name.Text != "")
                {
                    if (tb_login.Text != "")
                    {
                        if (pb_password.Password != "")
                        {
                            User userObj = new User()
                            {
                                surname = tb_surname.Text,
                                name = tb_name.Text,
                                patronymic = tb_patronymic.Text,
                                login = tb_login.Text,
                                password = pb_password.Password
                            };

                            OdbConnectHelper.entObj.User.Add(userObj);
                            OdbConnectHelper.entObj.SaveChanges();

                            MessageBox.Show("Зарегистрированно успешно",
                                            "Уведомление",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information
                                            );
                            FrameApp.frmObj.Navigate(new Pages.PagesOFAcc.PageLogin());
                        }
                        else
                        {
                            MessageBox.Show("Введите Пароль");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Введите Логин");
                    }
                }
                else
                {
                    MessageBox.Show("Введите Имя");
                }
            }
            else
            {
                MessageBox.Show("Введите Фамилию");
            }
        }
        private void LimitTextWithouZap_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            TextBox tbne = sender as TextBox;
            if ((!Char.IsDigit(e.Text, 0)) && (e.Text != ","))
            {
                { e.Handled = true; }
            }
            else
                if ((e.Text == ",") && ((tbne.Text.IndexOf(",") != -1) || (tbne.Text == "")))
            { e.Handled = true; }
        }
        private void LimitCifri_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }
        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }
        private void LimitOfSpace_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
    }
}
